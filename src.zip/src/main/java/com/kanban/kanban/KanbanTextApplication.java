package com.kanban.kanban;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.kanban.kanban")
public class KanbanTextApplication {

	public static void main(String[] args) {
		SpringApplication.run(KanbanTextApplication.class, args);
	}

}
