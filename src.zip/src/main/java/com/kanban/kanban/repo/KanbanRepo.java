package com.kanban.kanban.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.kanban.kanban.model.User;

@Repository
public interface KanbanRepo extends JpaRepository<User, Long> {

	User findByEmailId(String emailId);

}
