package com.kanban.kanban.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.kanban.kanban.model.Task;

@Repository("taskRepo")
public interface TaskRepo extends JpaRepository<Task, Long> {

}
