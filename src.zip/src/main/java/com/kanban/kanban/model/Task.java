package com.kanban.kanban.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "\"Kanban_Task\"")
@Setter
@Getter
public class Task {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "\"TaskId\"")
	private Long taskId;
	@Column(name = "\"Task_Code\"")
	private String taskCode;
	@Column(name = "\"Task_Name\"")
	private String taskName;
	@Column(name = "\"Is_Active\"")
	private Boolean isActive = false;
	@Column(name = "\"Is_Backlog\"")
	private Boolean isBacklog = false;
	@Column(name = "\"Is_TODO\"")
	private Boolean isToDo = false;
	@Column(name = "\"Is_Ongoing\"")
	private Boolean isOngoing = false;
}
