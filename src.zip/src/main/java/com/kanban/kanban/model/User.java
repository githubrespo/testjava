package com.kanban.kanban.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "\"Kanban_User\"")
@Setter
@Getter
public class User implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	//@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "\"Kanban_UserId_seq\"")
	//@SequenceGenerator(name = "\"Kanban_UserId_seq\"", sequenceName = "\"Kanban_UserId_seq\"", allocationSize = 50)
	@Column(name = "\"UserId\"")
	private Long userId;

	@Column(name = "\"Name\"")
	private String userName;

	@NotEmpty
	@Email
	@Column(name = "\"EmailId\"")
	private String emailId;

	@Size(min = 6, max = 10, message = "Size.userform.password")
	@Column(name = "\"Password\"")
	private String password;

}
