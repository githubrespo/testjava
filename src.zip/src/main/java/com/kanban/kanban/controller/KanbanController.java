package com.kanban.kanban.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.kanban.kanban.dao.KanbanService;
import com.kanban.kanban.model.Task;
import com.kanban.kanban.model.User;

@Controller()
public class KanbanController {

	@Autowired
	private KanbanService kanbanService;

	public KanbanController(KanbanService kanbanService) {
		this.kanbanService = kanbanService;
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView login(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView("index");
		User user = new User();
		model.addObject("user", user);
		return model;
	}

	@RequestMapping(value = "/userRegister", method = RequestMethod.GET)
	public ModelAndView register(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView("/registration");
		User user = new User();
		model.addObject("message", "UserRegistration");
		model.addObject("user", user);
		return model;
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView register(HttpServletRequest request, HttpServletResponse response,
			@Valid @ModelAttribute("user") User user, BindingResult br) {
		ModelAndView model = null;

		if (br.hasErrors()) {

			model = new ModelAndView("/registration");
			model.addObject("message", "UserRegistration");
			return model;
		}
		boolean isExistUser = kanbanService.isValidUser(user.getEmailId(), user.getPassword());
		if (isExistUser) {
			model = new ModelAndView("/index");
			model.addObject("message", "Already exists! please Login!");
			return model;
		}
		try {
			boolean isValidUser = kanbanService.saveUser(user);
			if (isValidUser) {
				request.setAttribute("message", "User Registration Successful " + user.getUserName());
				User newUser = new User();
				model = new ModelAndView("/index");
				model.addObject("user", newUser);
			} else {
				model = new ModelAndView("/registration");
				model.addObject("user", user);
				request.setAttribute("message", "Invalid credentials!!");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return model;
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView userLogin(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("user") User user, BindingResult br) {
		ModelAndView model = null;
		if (br.hasErrors()) {

			model = new ModelAndView("/index");
			model.addObject("user", user);
			return model;
		}
		try {
			boolean isValidUser = kanbanService.isValidUser(user.getEmailId(), user.getPassword());
			if (isValidUser) {
				System.out.println("User Login Successful");
				Task task = new Task();
				model = new ModelAndView("/kanban");
				model.addObject("task", task);
				request.setAttribute("loggedInUser", user.getUserName());

				request.setAttribute("message", "User Login Successful");
			} else {
				model = new ModelAndView("/index");
				model.addObject("user", user);
				request.setAttribute("message", "Invalid credentials!!");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return model;
	}
}
