package com.kanban.kanban.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.kanban.kanban.dao.KanbanService;
import com.kanban.kanban.model.Task;

@Controller
public class TaskController {

	@Autowired
	private KanbanService kanbanService;

	@RequestMapping(value = "/tracker", method = RequestMethod.GET)
	public ModelAndView login(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView("/taskTracker");
		Task task = new Task();
		model.addObject("task", task);
		return model;
	}

	@RequestMapping(value = "/createTask", method = RequestMethod.POST)
	public ModelAndView userLogin(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute("task") Task task, BindingResult br) {

		ModelAndView model = null;
		if (br.hasErrors()) {

			model = new ModelAndView("/index");
			model.addObject("task", task);
			return model;
		}

		try {
			model = new ModelAndView("/taskTracker");
			Random rand = new Random();
			String taskCode = "Task" + rand.nextInt(1000);
			task.setTaskCode(taskCode);
			task.setIsBacklog(true);
			task.setIsActive(true);
			kanbanService.saveTask(task);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}

	@RequestMapping(value = "/getTasklist", method = RequestMethod.GET)
	public ModelAndView getTask(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView("/taskTracker");
		Task task = new Task();

		List<Task> tasks = new ArrayList<Task>();
		tasks = kanbanService.getTasks();
		model.addObject("task", tasks);
		return model;
	}

	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public ModelAndView editCustomerForm(@RequestParam Long id) {
		ModelAndView model = new ModelAndView("/taskTracker");

		kanbanService.deleteTask(id);
		model.addObject("message", "taskDeleted");

		return model;
	}
}
