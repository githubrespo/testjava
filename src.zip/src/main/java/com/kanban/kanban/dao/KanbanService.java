package com.kanban.kanban.dao;

import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kanban.kanban.model.Task;
import com.kanban.kanban.model.User;
import com.kanban.kanban.repo.KanbanRepo;
import com.kanban.kanban.repo.TaskRepo;

@Service
public class KanbanService {

	@Autowired
	private KanbanRepo kanbanRepo;

	@Autowired
	private TaskRepo taskRepo;

	public boolean isValidUser(String emailId, String password) {
		// TODO Auto-generated method stub
		User user = kanbanRepo.findByEmailId(emailId);

		if (StringUtils.equals(emailId, user.getEmailId()) && StringUtils.equals(password, user.getPassword())
				&& user != null) {
			return true;
		}

		return false;
	}

	public boolean saveUser(User user) {

		kanbanRepo.save(user);

		return true;
	}

	public boolean saveTask(Task task) {

		taskRepo.save(task);

		return true;
	}

	public List<Task> getTasks() {

		List<Task> tasks = taskRepo.findAll();
		return tasks;

	}

	public void deleteTask(Long taskId) {
		Optional<Task> task = taskRepo.findById(taskId);
		if (task.isPresent()) {
			taskRepo.deleteById(taskId);
		}
	}

}
